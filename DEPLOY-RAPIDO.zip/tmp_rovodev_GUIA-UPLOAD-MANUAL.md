# 📤 GUIA DE UPLOAD MANUAL - CPANEL

## ✅ Arquivos Prontos para Upload

Você tem **3 arquivos** prontos na pasta do projeto:

1. ✅ **index-cpanel.html** (442 linhas) - Landing page completa
2. ✅ **styles.css** (890 linhas) - Todos os estilos
3. ✅ **script.js** (119 linhas) - Todas as funcionalidades

---

## 🎯 PASSO A PASSO SIMPLES

### PASSO 1: Acesse o cPanel
1. Abra seu navegador
2. Vá para: `seudominio.com/cpanel` ou o link que sua hospedagem forneceu
3. Faça login com suas credenciais

### PASSO 2: Abra o Gerenciador de Arquivos
1. No painel do cPanel, procure por **"Gerenciador de Arquivos"** ou **"File Manager"**
2. Clique para abrir
3. Navegue até a pasta **`public_html`**

### PASSO 3: Limpe a pasta (se necessário)
- Se já existir um `index.html` antigo, delete ou renomeie para backup
- Deixe a pasta `public_html` limpa para receber os novos arquivos

### PASSO 4: Faça o Upload
1. Clique no botão **"Upload"** ou **"Carregar"** (geralmente no topo)
2. Uma nova janela vai abrir
3. Clique em **"Selecionar Arquivo"** ou arraste os arquivos:
   - `index-cpanel.html`
   - `styles.css`
   - `script.js`
4. Aguarde a barra de progresso chegar em 100% para cada arquivo
5. Você verá uma mensagem de sucesso ✅

### PASSO 5: Renomeie o index-cpanel.html
1. Volte para o Gerenciador de Arquivos
2. Localize o arquivo **`index-cpanel.html`**
3. Clique com botão direito sobre ele
4. Escolha **"Rename"** ou **"Renomear"**
5. Mude o nome para: **`index.html`** (sem "cpanel" no nome)
6. Confirme

### PASSO 6: Verifique as Permissões (Recomendado)
Para cada um dos 3 arquivos:
1. Selecione o arquivo
2. Clique em **"Permissions"** ou **"Permissões"**
3. Configure como **644**:
   - ☑ Owner: Read, Write
   - ☑ Group: Read
   - ☑ World: Read
4. Salve

---

## ✅ CHECKLIST FINAL

Após o upload, verifique se você tem na pasta `public_html`:

- [ ] `index.html` (não index-cpanel.html!)
- [ ] `styles.css`
- [ ] `script.js`
- [ ] Todos com permissão 644

---

## 🎉 TESTE SEU SITE

1. Abra uma nova aba no navegador
2. Digite: `http://seudominio.com`
3. Seu site deve carregar com:
   - ✅ Menu de navegação funcionando
   - ✅ Design moderno em verde e branco
   - ✅ Seções: Hero, Problemas, Solução, etc.
   - ✅ FAQ com accordion
   - ✅ Botões de WhatsApp

---

## 🐛 PROBLEMAS COMUNS

### Site não aparece ou mostra página em branco:
- ✅ Confirme que o arquivo se chama `index.html` (não index-cpanel.html)
- ✅ Verifique se os 3 arquivos estão na pasta `public_html` (não em subpastas)
- ✅ Limpe o cache do navegador (Ctrl + F5)

### Design não aparece (só texto):
- ✅ Confirme que `styles.css` está na mesma pasta que `index.html`
- ✅ Verifique as permissões do arquivo CSS (deve ser 644)

### Botões e menu não funcionam:
- ✅ Confirme que `script.js` está na mesma pasta
- ✅ Verifique as permissões do arquivo JS (deve ser 644)

---

## 📍 LOCALIZAÇÃO DOS ARQUIVOS NO SEU COMPUTADOR

Os arquivos estão em:
```
C:\Users\Pc - Acer\OneDrive - 1nxbyl\Documentos\GitHub\midia-certa-vet\
```

Arquivos para upload:
- ✅ index-cpanel.html
- ✅ styles.css
- ✅ script.js

---

## 🆘 PRECISA DE AJUDA?

Se encontrar algum problema:
1. Tire um print da tela
2. Anote a mensagem de erro
3. Me avise que eu te ajudo!

---

**BOA SORTE! 🚀**

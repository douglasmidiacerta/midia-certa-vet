# 🚀 GUIA: Configurar Git no cPanel para Deploy Automático

## ✅ Status Atual:
- ✅ Repositório GitHub criado e atualizado
- ✅ URL: https://github.com/douglasmidiacerta/midia-certa-vet.git
- ✅ Código enviado para o GitHub
- ⏳ Aguardando configuração no cPanel

---

## 📋 PASSO A PASSO COMPLETO

### **PASSO 1: Acessar Git Version Control no cPanel**

1. Faça login no seu **cPanel**
2. Na busca, digite: **"Git"** ou **"Git Version Control"**
3. Clique em **"Git™ Version Control"**

---

### **PASSO 2: Criar Repositório no cPanel**

1. Clique no botão **"Create"** ou **"Criar"**

2. Preencha os campos:

   **Clone URL:**
   ```
   https://github.com/douglasmidiacerta/midia-certa-vet.git
   ```

   **Repository Path:** (caminho onde o Git vai clonar)
   ```
   /home/SEU-USUARIO/repositorios/midia-certa-vet
   ```
   ⚠️ **IMPORTANTE**: Substitua `SEU-USUARIO` pelo seu nome de usuário do cPanel
   
   **Repository Name:**
   ```
   midia-certa-vet
   ```

3. Clique em **"Create"** ou **"Criar"**

---

### **PASSO 3: Configurar Deploy Automático**

Após criar o repositório, você verá uma tela com opções.

1. Clique em **"Manage"** ou **"Gerenciar"** no repositório criado

2. Procure por uma opção chamada:
   - **"Pull or Deploy"** 
   - **"Update"**
   - **"Deploy Head"**

3. **IMPORTANTE**: Verifique se há uma opção para **"Enable Auto Deploy"** ou similar
   - Se tiver, ative!
   - Isso fará com que o cPanel atualize automaticamente quando você fizer push

---

### **PASSO 4: Configurar o arquivo .cpanel.yml**

O arquivo `.cpanel.yml` já está criado, mas precisa do seu nome de usuário.

**Me informe seu nome de usuário do cPanel e eu atualizo o arquivo para você!**

O arquivo vai copiar os arquivos do repositório Git para a pasta `public_html` automaticamente.

---

### **PASSO 5: Testar o Deploy Automático**

Depois de configurar tudo, vamos testar:

1. Fazer uma pequena alteração no código local
2. Commitar: `git add . && git commit -m "Teste de deploy"`
3. Enviar: `git push`
4. O cPanel deve detectar automaticamente e fazer o deploy!

---

## 🔧 ALTERNATIVA: Cron Job (Se não tiver auto-deploy)

Se seu cPanel não tiver opção de auto-deploy, podemos criar um Cron Job:

1. cPanel → **Cron Jobs**
2. Adicionar novo cron:
   
   **Frequência:** A cada 5 minutos
   ```
   */5 * * * *
   ```
   
   **Comando:**
   ```bash
   cd /home/SEU-USUARIO/repositorios/midia-certa-vet && git pull origin main
   ```

Isso vai verificar atualizações no GitHub a cada 5 minutos.

---

## 📝 INFORMAÇÕES NECESSÁRIAS

Para continuar, preciso saber:

1. **Qual é o seu nome de usuário do cPanel?**
   - Aparece no topo do painel após login
   - Ou em "Account Information"

2. **Você conseguiu acessar o Git Version Control?**
   - Se sim, me diga se apareceu alguma mensagem ou opção especial

3. **Quer que eu atualize o `.cpanel.yml` com seu usuário?**

---

## 🎯 PRÓXIMOS PASSOS

Depois que você me passar essas informações, vou:
1. ✅ Atualizar o arquivo `.cpanel.yml` com seu usuário correto
2. ✅ Fazer commit e push da alteração
3. ✅ Te guiar para configurar o deploy no cPanel
4. ✅ Testar o fluxo completo de deploy automático

---

**Me conte: qual é o seu nome de usuário do cPanel?** 😊
